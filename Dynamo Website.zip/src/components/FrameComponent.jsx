import PropTypes from "prop-types";
import styles from "./FrameComponent.module.css";

const FrameComponent = ({ className = "" }) => {
  return (
    <div className={[styles.bannerWrapper, className].join(" ")}>
      <div className={styles.banner}>
        <div className={styles.heroContent}>
          <h1 className={styles.discoverThePerfect}>
            Discover the Perfect Search Engine for you
          </h1>
          <div className={styles.unleashThePower}>
            Unleash the power of search with text, voice, and image generation
            all in one platform. Explore, interact, and create like never
            before.
          </div>
          <button className={styles.heroButton}>
            <div className={styles.tryItYourself}>Try it yourself</div>
            <img
              className={styles.heroButtonChild}
              alt=""
              src="/vector-7.svg"
            />
          </button>
          <img
            className={styles.statisticsIcon}
            loading="lazy"
            alt=""
            src="/vector-4.svg"
          />
        </div>
      </div>
    </div>
  );
};

FrameComponent.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent;
