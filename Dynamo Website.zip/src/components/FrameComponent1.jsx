import FeatureItems from "./FeatureItems";
import PropTypes from "prop-types";
import styles from "./FrameComponent1.module.css";

const FrameComponent1 = ({ className = "" }) => {
  return (
    <div className={[styles.featuresWrapper, className].join(" ")}>
      <div className={styles.features}>
        <h1 className={styles.whatDoWe}>What do we offer?</h1>
        <div className={styles.featureList}>
          <FeatureItems
            documentText="/documenttext.svg"
            aITextSearch="AI Text Search"
            searchThingsInAVeryAccurate="Search things in a very accurate and simpler form through Dynamo."
          />
          <FeatureItems
            documentText="/microphone.svg"
            aITextSearch="AI Voice Search"
            searchThingsInAVeryAccurate="Use your voice to search things and listen answer at the same time."
          />
          <FeatureItems
            documentText="/photograph.svg"
            aITextSearch="Image Generation"
            searchThingsInAVeryAccurate="Generate any type image on a single prompt."
          />
        </div>
      </div>
    </div>
  );
};

FrameComponent1.propTypes = {
  className: PropTypes.string,
};

export default FrameComponent1;
