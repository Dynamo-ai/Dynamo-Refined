import PropTypes from "prop-types";
import styles from "./LandingPageContent.module.css";

const LandingPageContent = ({ className = "" }) => {
  return (
    <div className={[styles.landingPageContent, className].join(" ")}>
      <div className={styles.frameParent}>
        <div className={styles.findThePerfectCreditCardFParent}>
          <h1 className={styles.findThePerfect}>
            Find the Perfect Credit Card for You
          </h1>
          <div className={styles.exploreTheFrontier}>
            Explore the frontier of creativity with AI image generation.
            Seamlessly convert your ideas into captivating visuals, where
            advanced algorithms and artistic vision merge. Discover how
            effortless it can be to bring your concepts to life with stunning
            detail and originality, transforming your imagination into
            extraordinary digital masterpieces
          </div>
        </div>
        <div className={styles.image4Parent}>
          <img className={styles.image4Icon} alt="" src="/image-4@2x.png" />
          <img
            className={styles.horseImage1}
            loading="lazy"
            alt=""
            src="/horse-image-1@2x.png"
          />
        </div>
      </div>
    </div>
  );
};

LandingPageContent.propTypes = {
  className: PropTypes.string,
};

export default LandingPageContent;
